public class Expression{
  
    private Node root;

    // DO NOT MODIFY THIS
    public Expression(){}

    // Build a Binary and Return the Root
    public Node Infix2BT(String infix){
        return(root);
    }

    public Node[] PrintPrefix(){
        Node[] prefix = null;
        return(prefix);
    }
  
    public Node[] PrintPostfix(){
        Node[] postfix = null;
        return(postfix);
    }

    public double Evaluation(){
        double answer = 0;
        return(answer);
    }
}